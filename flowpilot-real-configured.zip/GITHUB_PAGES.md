# نشر الواجهة على GitHub Pages

1. ارفع مجلد `public` إلى مستودع GitHub.
2. عدّل `public/config.js` ليشير إلى عنوان API الخلفي.
3. Settings → Pages → Deploy from branch.
4. اختر `main` + `/root` إذا كان `public` هو جذر المستودع، أو استخدم أي build step مناسب.

## Callback URLs

لا تضع callbacks على GitHub Pages. callbacks يجب أن تصل إلى Node API:

- `https://YOUR-API-DOMAIN/oauth/instagram/callback`
- `https://YOUR-API-DOMAIN/oauth/tiktok/callback`
