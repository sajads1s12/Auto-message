import express from 'express';
import multer from 'multer';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const DATA_DIR = path.join(__dirname, 'data');
const MEDIA_DIR = path.join(__dirname, 'media');
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(MEDIA_DIR, { recursive: true });

const PORT = Number(process.env.PORT || 8787);
const APP_ORIGIN = process.env.APP_ORIGIN || 'http://localhost:5500';
const API_ORIGIN = process.env.API_ORIGIN || `http://localhost:${PORT}`;
const COOKIE_NAME = 'fp_session';
const SESSION_SECRET = process.env.COOKIE_SECRET || 'dev-only-change-me';
const TOKEN_KEY = normalizeKey(process.env.TOKEN_ENCRYPTION_KEY || crypto.createHash('sha256').update(SESSION_SECRET).digest('base64'));
const INSTAGRAM_VERSION = process.env.INSTAGRAM_API_VERSION || 'v24.0';

function normalizeKey(value) {
  const b = Buffer.from(value, 'base64');
  if (b.length === 32) return b;
  return crypto.createHash('sha256').update(value).digest();
}
function db(file, fallback) {
  const p = path.join(DATA_DIR, file);
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { fs.writeFileSync(p, JSON.stringify(fallback, null, 2)); return fallback; }
}
const users = db('users.json', []);
const accounts = db('accounts.json', []);
const posts = db('posts.json', []);
const states = db('oauth_states.json', []);
function save(file, value) { fs.writeFileSync(path.join(DATA_DIR, file), JSON.stringify(value, null, 2)); }
function id(prefix='id') { return `${prefix}_${crypto.randomBytes(10).toString('hex')}`; }
function now() { return Date.now(); }
function publicUser(u) { return { id: u.id, username: u.username, createdAt: u.createdAt }; }
function passwordHash(password, salt = crypto.randomBytes(16).toString('hex')) {
  return `${salt}:${crypto.scryptSync(password, salt, 64).toString('hex')}`;
}
function passwordVerify(password, stored) {
  const [salt, hex] = String(stored).split(':');
  if (!salt || !hex) return false;
  const got = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(got, 'hex'), Buffer.from(hex, 'hex'));
}
function encrypt(text) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', TOKEN_KEY, iv);
  const encrypted = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
  return `${iv.toString('base64')}.${cipher.getAuthTag().toString('base64')}.${encrypted.toString('base64')}`;
}
function decrypt(payload) {
  const [ivB, tagB, dataB] = payload.split('.');
  const decipher = crypto.createDecipheriv('aes-256-gcm', TOKEN_KEY, Buffer.from(ivB, 'base64'));
  decipher.setAuthTag(Buffer.from(tagB, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(dataB, 'base64')), decipher.final()]).toString('utf8');
}
function sign(value) {
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(value).digest('base64url');
  return `${value}.${sig}`;
}
function verifySigned(value) {
  const idx = String(value || '').lastIndexOf('.');
  if (idx < 1) return null;
  const raw = value.slice(0, idx), sig = value.slice(idx + 1);
  const expected = crypto.createHmac('sha256', SESSION_SECRET).update(raw).digest('base64url');
  return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected)) ? raw : null;
}
function setCookie(res, token) {
  const secure = process.env.NODE_ENV === 'production';
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=${token}; HttpOnly; Path=/; SameSite=${secure ? 'None' : 'Lax'}; Max-Age=2592000${secure ? '; Secure' : ''}`);
}
function clearCookie(res) { res.setHeader('Set-Cookie', `${COOKIE_NAME}=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax`); }
function getUser(req) {
  const raw = (req.headers.cookie || '').split(';').map(x => x.trim()).find(x => x.startsWith(`${COOKIE_NAME}=`))?.slice(COOKIE_NAME.length + 1);
  const session = verifySigned(raw);
  if (!session) return null;
  const [userId, expires] = session.split('|');
  if (!userId || Number(expires) < now()) return null;
  return users.find(u => u.id === userId) || null;
}
function auth(req, res, next) { const u = getUser(req); if (!u) return res.status(401).json({ error: 'AUTH_REQUIRED' }); req.user = u; next(); }
function json(res, data, status=200) { return res.status(status).json(data); }
function randomState() { return crypto.randomBytes(24).toString('hex'); }
function cleanState() { for (let i = states.length - 1; i >= 0; i--) if (states[i].expiresAt < now()) states.splice(i, 1); save('oauth_states.json', states); }
function requireEnv(keys) { return keys.every(k => process.env[k]); }

const app = express();
app.set('trust proxy', 1);
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin === APP_ORIGIN || origin === 'http://localhost:5500' || origin === 'http://127.0.0.1:5500') {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Credentials', 'true');
  }
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
app.use(express.json({ limit: '2mb' }));

const upload = multer({
  dest: MEDIA_DIR,
  limits: { fileSize: 250 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => cb(null, /^video\/(mp4|quicktime|webm)$|^image\/(jpeg|png|webp)$/.test(file.mimetype))
});
app.use('/media', express.static(MEDIA_DIR, { maxAge: '1h' }));

app.get('/api/health', (_req, res) => json(res, { ok: true, service: 'FlowPilot API', time: new Date().toISOString() }));
app.get('/api/config/public', (_req, res) => json(res, { appOrigin: APP_ORIGIN, apiOrigin: API_ORIGIN, instagramReady: requireEnv(['INSTAGRAM_APP_ID','INSTAGRAM_APP_SECRET','INSTAGRAM_REDIRECT_URI']), tiktokReady: requireEnv(['TIKTOK_CLIENT_KEY','TIKTOK_CLIENT_SECRET','TIKTOK_REDIRECT_URI']) }));

app.post('/api/auth/register', (req, res) => {
  const username = String(req.body.username || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!/^[a-z0-9_]{3,24}$/.test(username)) return json(res, { error: 'INVALID_USERNAME' }, 400);
  if (password.length < 8) return json(res, { error: 'PASSWORD_TOO_SHORT' }, 400);
  if (users.some(u => u.username === username)) return json(res, { error: 'USERNAME_TAKEN' }, 409);
  const u = { id: id('usr'), username, passwordHash: passwordHash(password), createdAt: new Date().toISOString() };
  users.push(u); save('users.json', users);
  setCookie(res, sign(`${u.id}|${now()+2592000000}`));
  json(res, { user: publicUser(u) }, 201);
});
app.post('/api/auth/login', (req, res) => {
  const username = String(req.body.username || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const u = users.find(x => x.username === username);
  if (!u || !passwordVerify(password, u.passwordHash)) return json(res, { error: 'INVALID_CREDENTIALS' }, 401);
  setCookie(res, sign(`${u.id}|${now()+2592000000}`));
  json(res, { user: publicUser(u) });
});
app.post('/api/auth/logout', (_req, res) => { clearCookie(res); json(res, { ok: true }); });
app.get('/api/auth/me', auth, (req, res) => json(res, { user: publicUser(req.user) }));

app.get('/api/accounts', auth, (req, res) => {
  const data = accounts.filter(a => a.userId === req.user.id).map(a => ({ id:a.id, provider:a.provider, username:a.username, displayName:a.displayName, avatar:a.avatar, status:a.status, scopes:a.scopes || [] }));
  json(res, { accounts: data });
});
app.delete('/api/accounts/:id', auth, (req,res) => {
  const idx = accounts.findIndex(a => a.id === req.params.id && a.userId === req.user.id);
  if (idx < 0) return json(res, {error:'NOT_FOUND'},404);
  accounts.splice(idx,1); save('accounts.json',accounts); json(res,{ok:true});
});

function beginOAuth(provider, req, res) {
  cleanState();
  const state = randomState();
  states.push({ state, userId:req.user.id, provider, expiresAt:now()+10*60*1000 });
  save('oauth_states.json',states);
  if (provider === 'instagram') {
    if (!requireEnv(['INSTAGRAM_APP_ID','INSTAGRAM_REDIRECT_URI'])) return res.status(503).send('Instagram OAuth is not configured on the server.');
    const p = new URLSearchParams({ client_id:process.env.INSTAGRAM_APP_ID, redirect_uri:process.env.INSTAGRAM_REDIRECT_URI, response_type:'code', scope:'instagram_business_basic,instagram_business_content_publish', state });
    return res.redirect(`https://www.instagram.com/oauth/authorize?${p}`);
  }
  if (!requireEnv(['TIKTOK_CLIENT_KEY','TIKTOK_REDIRECT_URI'])) return res.status(503).send('TikTok OAuth is not configured on the server.');
  const p = new URLSearchParams({ client_key:process.env.TIKTOK_CLIENT_KEY, response_type:'code', scope:'user.info.basic,video.publish', redirect_uri:process.env.TIKTOK_REDIRECT_URI, state });
  return res.redirect(`https://www.tiktok.com/v2/auth/authorize/?${p}`);
}
app.get('/oauth/instagram/start', auth, (req,res)=>beginOAuth('instagram',req,res));
app.get('/oauth/tiktok/start', auth, (req,res)=>beginOAuth('tiktok',req,res));

async function tokenInstagram(code) {
  const body = new URLSearchParams({ client_id:process.env.INSTAGRAM_APP_ID, client_secret:process.env.INSTAGRAM_APP_SECRET, grant_type:'authorization_code', redirect_uri:process.env.INSTAGRAM_REDIRECT_URI, code });
  const r = await fetch('https://api.instagram.com/oauth/access_token', {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});
  if (!r.ok) throw new Error(`Instagram token exchange failed: ${r.status}`);
  const first = await r.json();
  let accessToken = first.access_token;
  try {
    const u = new URL(`https://graph.instagram.com/${INSTAGRAM_VERSION}/access_token`);
    u.searchParams.set('grant_type','ig_exchange_token'); u.searchParams.set('client_secret',process.env.INSTAGRAM_APP_SECRET); u.searchParams.set('access_token',accessToken);
    const longR = await fetch(u); if (longR.ok) accessToken = (await longR.json()).access_token || accessToken;
  } catch {}
  const p = new URL(`https://graph.instagram.com/${INSTAGRAM_VERSION}/me`); p.searchParams.set('fields','user_id,username,name,profile_picture_url'); p.searchParams.set('access_token',accessToken);
  const profileR = await fetch(p); if (!profileR.ok) throw new Error(`Instagram profile failed: ${profileR.status}`);
  const profile = await profileR.json();
  return {accessToken, profile, scopes:['instagram_business_basic','instagram_business_content_publish']};
}
async function tokenTikTok(code) {
  const body = new URLSearchParams({ client_key:process.env.TIKTOK_CLIENT_KEY, client_secret:process.env.TIKTOK_CLIENT_SECRET, code, grant_type:'authorization_code', redirect_uri:process.env.TIKTOK_REDIRECT_URI });
  const r = await fetch('https://open.tiktokapis.com/v2/oauth/token/', {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});
  if (!r.ok) throw new Error(`TikTok token exchange failed: ${r.status}`);
  const token = await r.json(); if (!token.access_token) throw new Error(token.error_description || token.error || 'TikTok token missing');
  const p = await fetch('https://open.tiktokapis.com/v2/user/info/?fields=open_id,display_name,avatar_url', {headers:{Authorization:`Bearer ${token.access_token}`}});
  if (!p.ok) throw new Error(`TikTok profile failed: ${p.status}`);
  const profile = await p.json();
  return {accessToken:token.access_token, refreshToken:token.refresh_token, profile:profile.data?.user || {}, scopes:['user.info.basic','video.publish'], expiresIn:token.expires_in};
}
async function oauthCallback(provider, req, res) {
  cleanState();
  const row = states.find(s => s.state === req.query.state && s.provider === provider);
  if (!row) return res.status(400).send('OAuth state expired or invalid.');
  const code = req.query.code;
  if (!code) return res.status(400).send(`OAuth denied: ${req.query.error_description || req.query.error || 'no code'}`);
  try {
    const out = provider === 'instagram' ? await tokenInstagram(code) : await tokenTikTok(code);
    const existing = accounts.findIndex(a => a.userId===row.userId && a.provider===provider && (a.providerId === out.profile.user_id || a.providerId === out.profile.open_id));
    const record = { id: existing>=0 ? accounts[existing].id : id('acc'), userId:row.userId, provider, providerId:out.profile.user_id || out.profile.open_id, username:out.profile.username || out.profile.display_name || 'Connected account', displayName:out.profile.name || out.profile.display_name || '', avatar:out.profile.profile_picture_url || out.profile.avatar_url || '', status:'connected', scopes:out.scopes, accessToken:encrypt(out.accessToken), refreshToken:out.refreshToken ? encrypt(out.refreshToken) : null, tokenExpiresAt: out.expiresIn ? now()+Number(out.expiresIn)*1000 : null, updatedAt:new Date().toISOString() };
    if (existing>=0) accounts[existing]=record; else accounts.push(record); save('accounts.json',accounts);
    states.splice(states.indexOf(row),1); save('oauth_states.json',states);
    res.redirect(`${APP_ORIGIN}/?connected=${provider}`);
  } catch (e) { console.error(e); res.redirect(`${APP_ORIGIN}/?oauth_error=${encodeURIComponent(e.message)}`); }
}
app.get('/oauth/instagram/callback', (req,res)=>oauthCallback('instagram',req,res));
app.get('/oauth/tiktok/callback', (req,res)=>oauthCallback('tiktok',req,res));

app.post('/api/media', auth, upload.single('file'), (req,res) => {
  if (!req.file) return json(res,{error:'INVALID_MEDIA'},400);
  const finalName = `${req.user.id}_${Date.now()}_${path.extname(req.file.originalname).replace(/[^.a-z0-9]/gi,'') || '.bin'}`;
  const finalPath = path.join(MEDIA_DIR,finalName);
  fs.renameSync(req.file.path, finalPath);
  json(res,{id:id('media'), url:`${API_ORIGIN}/media/${finalName}`, filename:req.file.originalname, mimetype:req.file.mimetype, size:req.file.size});
});

app.get('/api/posts', auth, (req,res)=>json(res,{posts:posts.filter(p=>p.userId===req.user.id).sort((a,b)=>new Date(a.scheduledAt||a.createdAt)-new Date(b.scheduledAt||b.createdAt)).map(({userId,...p})=>p)}));
app.post('/api/posts', auth, (req,res) => {
  const { accountIds=[], caption='', mediaUrl=null, mediaType=null, scheduledAt=null, publishNow=false, timezone='Asia/Baghdad' } = req.body || {};
  if (!Array.isArray(accountIds) || !accountIds.length) return json(res,{error:'NO_ACCOUNTS'},400);
  if (!caption.trim() && !mediaUrl) return json(res,{error:'EMPTY_POST'},400);
  const owned=accountIds.every(x=>accounts.some(a=>a.id===x&&a.userId===req.user.id)); if(!owned) return json(res,{error:'INVALID_ACCOUNT'},400);
  const p={id:id('post'),userId:req.user.id,accountIds,caption:String(caption),mediaUrl,mediaType,scheduledAt:scheduledAt || new Date().toISOString(),publishNow:Boolean(publishNow),timezone,status:publishNow?'publishing':'scheduled',results:[],createdAt:new Date().toISOString()};
  posts.push(p); save('posts.json',posts); if(p.publishNow) publishPost(p).catch(console.error); json(res,{post:({...p,userId:undefined})},201);
});
app.post('/api/posts/:id/run', auth, async (req,res)=>{ const p=posts.find(x=>x.id===req.params.id&&x.userId===req.user.id); if(!p) return json(res,{error:'NOT_FOUND'},404); await publishPost(p); json(res,{post:p}); });

async function publishPost(p) {
  const targets = accounts.filter(a=>p.accountIds.includes(a.id)&&a.userId===p.userId);
  p.status='publishing'; save('posts.json',posts);
  const results=[];
  for (const a of targets) {
    try {
      const token=decrypt(a.accessToken);
      let result;
      if(a.provider==='instagram') result=await publishInstagram(a,token,p);
      else if(a.provider==='tiktok') result=await publishTikTok(a,token,p);
      results.push({accountId:a.id,provider:a.provider,ok:true,result});
    } catch(e) { results.push({accountId:a.id,provider:a.provider,ok:false,error:e.message}); }
  }
  p.results=results; p.status=results.some(x=>x.ok)?'published': 'failed'; p.publishedAt=new Date().toISOString(); save('posts.json',posts);
}
async function publishInstagram(account,token,p) {
  if(!p.mediaUrl) throw new Error('Instagram publishing requires an image or video URL.');
  const base=`https://graph.instagram.com/${INSTAGRAM_VERSION}/${account.providerId}`;
  const body=new URLSearchParams({caption:p.caption||''});
  if((p.mediaType||'').startsWith('video/')) { body.set('media_type','REELS'); body.set('video_url',p.mediaUrl); }
  else body.set('image_url',p.mediaUrl);
  body.set('access_token',token);
  const c=await fetch(`${base}/media`,{method:'POST',body}); if(!c.ok) throw new Error(`Instagram container failed: ${c.status} ${await c.text()}`);
  const container=(await c.json()).id; let status='IN_PROGRESS';
  for(let i=0;i<24 && status==='IN_PROGRESS';i++){ await new Promise(r=>setTimeout(r,5000)); const u=new URL(`https://graph.instagram.com/${INSTAGRAM_VERSION}/${container}`); u.searchParams.set('fields','status_code');u.searchParams.set('access_token',token);const r=await fetch(u);if(!r.ok) break;status=(await r.json()).status_code||'IN_PROGRESS'; }
  if(status==='ERROR'||status==='EXPIRED') throw new Error(`Instagram media status: ${status}`);
  const pub=await fetch(`${base}/media_publish?creation_id=${encodeURIComponent(container)}&access_token=${encodeURIComponent(token)}`,{method:'POST'}); if(!pub.ok) throw new Error(`Instagram publish failed: ${pub.status} ${await pub.text()}`);
  return await pub.json();
}
async function publishTikTok(account,token,p) {
  if(!p.mediaUrl || !(p.mediaType||'').startsWith('video/')) throw new Error('TikTok Direct Post currently expects a video in this build.');
  const fileName = path.basename(new URL(p.mediaUrl).pathname);
  const filePath = path.join(MEDIA_DIR,fileName);
  if(!fs.existsSync(filePath)) throw new Error('The uploaded media file is no longer available on the server.');
  const stat = fs.statSync(filePath);
  const size = stat.size;
  const maxChunk = 50 * 1024 * 1024;
  const chunkSize = Math.min(size, maxChunk);
  const totalChunks = Math.ceil(size / chunkSize);
  const ci=await fetch('https://open.tiktokapis.com/v2/post/publish/creator_info/query/',{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'}}); if(!ci.ok) throw new Error(`TikTok creator info failed: ${ci.status} ${await ci.text()}`);
  const info=await ci.json();
  const maxDuration = Number(info.data?.max_video_post_duration_sec || 0);
  if(info.data?.can_post === false) throw new Error('TikTok creator is currently unable to create more posts.');
  const privacy=(info.data?.privacy_level_options||[])[0] || 'SELF_ONLY';
  const init=await fetch('https://open.tiktokapis.com/v2/post/publish/video/init/',{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({post_info:{title:p.caption||'',privacy_level:privacy},source_info:{source:'FILE_UPLOAD',video_size:size,chunk_size:chunkSize,total_chunk_count:totalChunks}})});
  if(!init.ok) throw new Error(`TikTok init failed: ${init.status} ${await init.text()}`);
  const initJson=await init.json();
  const uploadUrl=initJson.data?.upload_url;
  const publishId=initJson.data?.publish_id;
  if(!uploadUrl || !publishId) throw new Error('TikTok did not return an upload URL.');
  const handle=await fs.promises.open(filePath,'r');
  try {
    for(let i=0;i<totalChunks;i++){
      const start=i*chunkSize; const len=Math.min(chunkSize,size-start); const buf=Buffer.alloc(len); await handle.read(buf,0,len,start);
      const put=await fetch(uploadUrl,{method:'PUT',headers:{'Content-Type':p.mediaType || 'video/mp4','Content-Length':String(len),'Content-Range':`bytes ${start}-${start+len-1}/${size}`},body:buf});
      if(!put.ok) throw new Error(`TikTok upload chunk ${i+1}/${totalChunks} failed: ${put.status} ${await put.text()}`);
    }
  } finally { await handle.close(); }
  let status='PROCESSING_UPLOAD', latest={publish_id:publishId};
  for(let i=0;i<12;i++){
    await new Promise(r=>setTimeout(r,5000));
    const sr=await fetch('https://open.tiktokapis.com/v2/post/publish/status/fetch/',{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({publish_id:publishId})});
    if(!sr.ok) break;
    latest=await sr.json(); status=latest.data?.status || status;
    if(status==='PUBLISH_COMPLETE' || status==='FAILED') break;
  }
  return {...latest, maxDuration};
}

setInterval(async()=>{
  for(const p of posts.slice()) {
    if(p.status==='scheduled' && p.scheduledAt && new Date(p.scheduledAt).getTime()<=now()) await publishPost(p).catch(e=>{p.status='failed';p.error=e.message;save('posts.json',posts)});
  }
},15000);

app.listen(PORT,()=>console.log(`FlowPilot API listening on ${API_ORIGIN}`));
