window.FLOWPILOT_CONFIG = {
  API_ORIGIN: 'http://localhost:8787'
};
