# FlowPilot — Real Social Publishing Workspace

نسخة عملية من واجهة Buffer، لكن باسم وتصميم مستقلين وبنية Frontend + API.

## ماذا تعمل فعلياً؟

- تسجيل دخول بحساب المشروع بدون بريد إلكتروني: username + password.
- ربط Instagram Professional عبر OAuth الحقيقي.
- ربط TikTok عبر TikTok Login Kit.
- حفظ access/refresh tokens مشفّرة على السيرفر، وليس داخل GitHub Pages.
- رفع فيديو/صورة إلى السيرفر.
- إنشاء منشور، نشر الآن أو جدولة.
- Worker بسيط داخل Node يفحص المنشورات المجدولة كل 15 ثانية.
- Instagram: نشر صورة أو Reel عبر Instagram API with Instagram Login.
- TikTok: Direct Post للفيديو في هذا الإصدار.

## مهم جداً قبل الإنتاج

GitHub Pages يستضيف ملفات الواجهة فقط. شغّل مجلد `server` كخدمة Node منفصلة، ثم ضع رابطها في `public/config.js`.

### 1) شغل محلياً

```bash
npm install
cp .env.example .env
npm start
```

شغّل واجهة `public/` بأي static server، مثلاً:

```bash
npx serve public -l 5500
```

ثم افتح `http://localhost:5500`.

### 2) Instagram

أنشئ/استخدم Meta app وفعل Instagram Login للمحترفين، ثم ضع:

- `INSTAGRAM_APP_ID`
- `INSTAGRAM_APP_SECRET`
- `INSTAGRAM_REDIRECT_URI`

والـredirect يجب أن يكون عنوان HTTPS العام للـAPI:

`https://YOUR-API-DOMAIN/oauth/instagram/callback`

صلاحيات هذا المشروع:

- `instagram_business_basic`
- `instagram_business_content_publish`

### 3) TikTok

ضع:

- `TIKTOK_CLIENT_KEY`
- `TIKTOK_CLIENT_SECRET`
- `TIKTOK_REDIRECT_URI`

والـredirect:

`https://YOUR-API-DOMAIN/oauth/tiktok/callback`

صلاحيات هذا المشروع:

- `user.info.basic`
- `video.publish`

### 4) GitHub Pages

ارفع محتويات `public/` إلى repo، وعدّل `public/config.js` إلى رابط API الحقيقي:

```js
window.FLOWPILOT_CONFIG = { API_ORIGIN: 'https://YOUR-API-DOMAIN' };
```

ثم فعّل GitHub Pages من Settings → Pages.

### 5) الأمان

لا ترفع `.env` إلى GitHub. لا تضع App Secret أو access tokens في `public/` أو JavaScript للمتصفح.

للاستخدام العام/التجاري، استبدل مخزن JSON بقاعدة بيانات حقيقية، وأضف rate limiting، backups، HTTPS، مراقبة jobs، واسترجاع tokens عند انتهاء الصلاحية.
