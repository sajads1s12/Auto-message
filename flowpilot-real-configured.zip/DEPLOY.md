# النشر الفعلي

## الواجهة

المجلد `site/` هو الواجهة التي تُنشر على GitHub Pages. عدّل `site/config.js` واجعل `API_ORIGIN` يساوي رابط الـAPI العام.

## الخادم

المجلد `server/` هو الـBackend. أسهل مسار: نشر المشروع كـDocker Web Service باستخدام `render.yaml`، أو تشغيله على أي Node.js host.

يجب أن يكون للـAPI عنوان HTTPS عام لأن مزودي الشبكات الاجتماعية يرجعون المستخدم إلى OAuth callback، كما أن روابط الوسائط التي تحتاجها بعض واجهات النشر يجب أن تكون قابلة للوصول من الإنترنت.

## Meta / Instagram

سجّل هذه callback URL في إعدادات التطبيق:

`https://YOUR-API-DOMAIN/oauth/instagram/callback`

استخدم Instagram Login لحسابات Instagram Professional، والصلاحيات الموجودة في `.env.example`.

## TikTok

سجّل:

`https://YOUR-API-DOMAIN/oauth/tiktok/callback`

ويجب أن يكون تطبيق TikTok مفعّل عليه Content Posting API والصلاحيات المطلوبة للنشر المباشر.
